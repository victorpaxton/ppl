1. java -jar ./antlr-4.9.2-complete.jar BKIT.g4 
2. javac -classpath ./antlr-4.9.2-complete.jar BKIT*.java
3. java -cp ".:./antlr-4.9.2-complete.jar" org.antlr.v4.gui.TestRig BKIT program -gui input.txt